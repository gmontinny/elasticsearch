from .hotels import Hotels # noqa
from .hotel import Hotel # noqa
from .booking import Booking # noqa
from .comment import Comment # noqa