<?php

namespace App\DependencyInjection\HotelSearchCriteria;

abstract class AbstractCriteriaDirector
{
    abstract public function __construct(AbstractCriteriaBuilder $builder);

    abstract public function buildCriteria();

    abstract public function getCriteria();
}
