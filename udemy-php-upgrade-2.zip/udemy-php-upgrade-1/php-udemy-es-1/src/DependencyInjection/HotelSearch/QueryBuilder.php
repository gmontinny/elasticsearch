<?php

namespace App\DependencyInjection\HotelSearch;

use App\DependencyInjection\HotelSearch\Filters\CityNameFilter;
use App\DependencyInjection\HotelSearch\Filters\GeoDistanceFilter;
use App\DependencyInjection\HotelSearch\Filters\HotelNameFilter;
use App\DependencyInjection\HotelSearch\Filters\HotelRangeFilter;
use App\Entity\HotelSearchCriteria;
use ONGR\ElasticsearchBundle\Service\IndexService;
use ONGR\ElasticsearchDSL\Query\Compound\BoolQuery;
use ONGR\ElasticsearchDSL\Search;

class QueryBuilder implements QueryBuilderInterface
{
    /**
     * @var Search
     */
    protected $search;

    public function __construct(IndexService $indexService)
    {
        $this->search = $indexService->createSearch();
    }

    /**
     * @param HotelSearchCriteria $criteria
     */
    public function createQuery(HotelSearchCriteria $criteria): void
    {
        $this->setPageOffset($criteria);
        $this->setFields($criteria);
        $this->setFilters($criteria);
        $this->setAggregation($criteria);
        $this->setSorting($criteria);
    }

    /**
     * @return Search
     */
    public function getSearch(): Search
    {
        return $this->search;
    }

    /**
     * @param HotelSearchCriteria $criteria
     */
    public function setFilters(HotelSearchCriteria $criteria)
    {
        if ($criteria->getCityName()) {
            $this->search->addQuery(
                CityNameFilter::createFilter($criteria),
                BoolQuery::MUST
            );
        }

        if ($criteria->getHotelName()) {
            $this->search->addQuery(
                HotelNameFilter::createFilter($criteria),
                BoolQuery::MUST
            );
        }

        if ($criteria->getHotelAge()) {
            $this->search->addQuery(
                HotelRangeFilter::createFilter($criteria),
                BoolQuery::SHOULD
            );
        }

        if ($criteria->getGeoCoordinates()) {
            $this->search->addQuery(
                GeoDistanceFilter::createFilter($criteria),
                BoolQuery::FILTER
            );
        }
    }

    /**
     * set page offset for document search
     * @param HotelSearchCriteria $criteria
     */
    protected function setPageOffset(HotelSearchCriteria $criteria)
    {
        $startFrom = ($criteria->getPage() - 1) * $criteria->getSize();
        $startFrom = $startFrom <= 0 ? 0 : $startFrom;

        $this->search->setFrom($startFrom);
        $this->search->setSize($criteria->getSize());
    }

    /**
     * @param HotelSearchCriteria $criteria
     */
    protected function setFields(HotelSearchCriteria $criteria)
    {
        //choose fields you want to get from ElasticSearch
    }

    /**
     * @param HotelSearchCriteria $criteria
     */
    protected function setAggregation(HotelSearchCriteria $criteria)
    {
        //add aggregations
    }

    /**
     * @param HotelSearchCriteria $criteria
     */
    protected function setSorting(HotelSearchCriteria $criteria)
    {
        //add sorting
    }
}
