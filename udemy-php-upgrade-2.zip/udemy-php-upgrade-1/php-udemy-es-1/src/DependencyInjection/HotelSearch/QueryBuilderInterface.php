<?php

namespace App\DependencyInjection\HotelSearch;

use App\Entity\HotelSearchCriteria;

interface QueryBuilderInterface
{
    public function createQuery(HotelSearchCriteria $criteria): void;

    public function getSearch(): \ONGR\ElasticsearchDSL\Search;
}
