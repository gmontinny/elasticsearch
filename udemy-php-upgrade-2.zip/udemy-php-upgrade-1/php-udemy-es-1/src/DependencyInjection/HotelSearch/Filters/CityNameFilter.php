<?php

namespace App\DependencyInjection\HotelSearch\Filters;

use App\Entity\HotelSearchCriteria;
use ONGR\ElasticsearchDSL\BuilderInterface;
use ONGR\ElasticsearchDSL\Query\Compound\BoolQuery;
use ONGR\ElasticsearchDSL\Query\FullText\MatchQuery;

class CityNameFilter extends AbstractFilter
{
    const FUZZINESS = 2;

    public static function createFilter(HotelSearchCriteria $criteria): BuilderInterface
    {
        $boolQuery = new BoolQuery();
        $boolQuery->add(
            new MatchQuery(
                'hotel.city_name_en',
                $criteria->getCityName(),
                ['fuzziness' => self::FUZZINESS]
            ),
            BoolQuery::SHOULD
        );

        $boolQuery->add(
            new MatchQuery(
                'hotel.city_name_en',
                'London',
                []
            ),
            BoolQuery::SHOULD
        );

        return $boolQuery;
    }
}
