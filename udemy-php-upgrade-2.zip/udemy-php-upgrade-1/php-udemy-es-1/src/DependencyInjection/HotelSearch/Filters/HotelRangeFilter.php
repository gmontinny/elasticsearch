<?php

namespace App\DependencyInjection\HotelSearch\Filters;

use App\Entity\HotelSearchCriteria;
use ONGR\ElasticsearchDSL\BuilderInterface;
use ONGR\ElasticsearchDSL\Query\Compound\BoolQuery;
use ONGR\ElasticsearchDSL\Query\TermLevel\RangeQuery;

class HotelRangeFilter extends AbstractFilter
{
    public static function createFilter(HotelSearchCriteria $criteria): BuilderInterface
    {
        $boolQuery = new BoolQuery();
        $rangeQuery = new RangeQuery(
            'hotel.age',
            ['from' => $criteria->getHotelAge()]
        );

        $boolQuery->add($rangeQuery, BoolQuery::MUST);

        return $boolQuery;
    }
}
