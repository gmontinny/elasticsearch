<?php

namespace App\DependencyInjection\HotelSearch\Filters;

use App\Entity\HotelSearchCriteria;
use ONGR\ElasticsearchDSL\BuilderInterface;

abstract class AbstractFilter
{
    abstract public static function createFilter(HotelSearchCriteria $criteria): BuilderInterface;
}
