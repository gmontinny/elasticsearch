<?php

namespace App\DependencyInjection\HotelSearch;

use App\Entity\HotelSearchCriteria;
use ONGR\ElasticsearchBundle\Result\DocumentIterator;
use ONGR\ElasticsearchBundle\Result\RawIterator;
use ONGR\ElasticsearchDSL\Search as SearchDSL;
use ONGR\ElasticsearchBundle\Service\IndexService;

class Search
{
    /**
     * End points - used for clearing search object
     */
    private static $endpoints = [
        'aggregations' => 'ONGR\ElasticsearchDSL\SearchEndpoint\AggregationsEndpoint',
        'highlight' => 'ONGR\ElasticsearchDSL\SearchEndpoint\HighlightEndpoint',
        'inner_hits' => 'ONGR\ElasticsearchDSL\SearchEndpoint\InnerHitsEndpoint',
        'post_filter' => 'ONGR\ElasticsearchDSL\SearchEndpoint\PostFilterEndpoint',
        'query' => 'ONGR\ElasticsearchDSL\SearchEndpoint\QueryEndpoint',
        'sort' => 'ONGR\ElasticsearchDSL\SearchEndpoint\SortEndpoint',
        'suggest' => 'ONGR\ElasticsearchDSL\SearchEndpoint\SuggestEndpoint'
    ];

    /**
     * @var IndexService
     */
    private $indexService;
    /**
     * @var QueryBuilder
     */
    private $builder;

    public function __construct(IndexService $indexService, QueryBuilder $builder)
    {
        $this->indexService = $indexService;
        $this->builder = $builder;
    }

    /**
     * @param HotelSearchCriteria $criteria
     * @return DocumentIterator
     */
    public function search(HotelSearchCriteria $criteria)
    {
        $this->builder->createQuery($criteria);
        $search = $this->builder->getSearch();

        $results =  $this->indexService->findDocuments($search);
        $this->clear($search);

        return $results;
    }

    /**
     * @param HotelSearchCriteria $criteria
     * @return RawIterator
     */
    public function searchRaw(HotelSearchCriteria $criteria)
    {
        $this->builder->createQuery($criteria);
        $search = $this->builder->getSearch();

        $results =  $this->indexService->findRaw($search);
        $this->clear($search);

        return $results;
    }

    /**
     * Clear all filters.
     *
     * @param SearchDSL $search
     * @return void
     */
    public function clear(SearchDSL $search)
    {
        foreach (self::$endpoints as $type => $value) {
            $search->destroyEndpoint($type);
        }
    }
}
