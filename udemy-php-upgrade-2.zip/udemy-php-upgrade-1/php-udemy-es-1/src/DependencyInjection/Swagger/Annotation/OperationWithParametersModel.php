<?php

namespace App\DependencyInjection\Swagger\Annotation;

use App\DependencyInjection\Swagger\ReflectionClassSwaggerParameterCreator;
use Nelmio\ApiDocBundle\Annotation\Operation;

/**
 * Class OperationWithParametersModel
 *
 * Extends the Swagger Operation annotation in order to automatically add the proper parameters' annotations using an
 * existing reusable DTD model class. The same DTD model can be used in the multiple API methods to define the query
 * parameters - which is not supported by default in Swagger.
 *
 * @Annotation
 * @package ApiBundle\Model\Request\Auction
 */
class OperationWithParametersModel extends Operation
{
    /**
     * Class name of the parameters model
     * @var string
     */
    private $parametersModel;

    public function __construct($properties)
    {
        parent::__construct($this->applyParametersFromModel($properties));
    }

    /**
     * @param array $properties
     * @return array
     * @throws \ReflectionException
     * @throws \LogicException
     */
    private function applyParametersFromModel(array $properties): array
    {
        if (empty($properties['parametersModel'])) {
            throw new \LogicException('Missing parametersModel field for the OperationWithParametersModel annotation.');
        }

        // Create parameters from model
        $this->parametersModel = $properties['parametersModel'];
        unset($properties['parametersModel']);
        $parametersModelAnalyzer = new ReflectionClassSwaggerParameterCreator();
        $parameters = $parametersModelAnalyzer->createParameters($this->parametersModel);

        // Merge parameters array
        if (empty($properties['parameters'])) {
            $properties['parameters'] = [];
        }
        $properties['parameters'] = array_merge($properties['parameters'], $parameters);

        return $properties;
    }
}
