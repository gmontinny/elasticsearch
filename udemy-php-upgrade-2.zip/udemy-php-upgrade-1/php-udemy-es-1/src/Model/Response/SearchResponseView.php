<?php

namespace App\Model\Response;

class SearchResponseView
{
    /**
     * List of the searching results (auctions).
     * @var SimpleSearchItemView[]
     */
    private $results;

    /**
     * @return SimpleSearchItemView[]
     */
    public function getResults(): array
    {
        return $this->results;
    }

    /**
     * @param SimpleSearchItemView[] $results
     */
    public function setResults(array $results): void
    {
        $this->results = $results;
    }
}
