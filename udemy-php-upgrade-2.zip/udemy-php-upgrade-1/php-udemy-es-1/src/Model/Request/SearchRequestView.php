<?php

namespace App\Model\Request;

use OpenApi\Annotations as OA;
use App\Entity\HotelSearchCriteria;

class SearchRequestView
{
    /**
     * Page number
     *  @OA\Parameter(
     *     required=false,
     *     @OA\Schema(
     *         type="integer",
     *         default=1,
     *         minimum=1
     *     )
     *  )
     * @var int
     */
    protected $page = 1;

    /**
     * Page size
     *  @OA\Parameter(
     *     required=false,
     *     @OA\Schema(
     *         default=HotelSearchCriteria::DEFAULT_SIZE,
     *         minimum=HotelSearchCriteria::SIZE_MIN,
     *         maximum=HotelSearchCriteria::SIZE_MAX
     *     )
     *  )
     * @var int
     */
    protected $size = 10;
    /**
     * Hotel name
     * @OA\Parameter(required=true)
     * @var string|null
     */
    protected $n;

    /**
     * City name at English
     * @OA\Parameter(required=true)
     * @var string|null
     */
    protected $c;

    /**
     * Latitude of the city center
     * @var double|null
     */
    protected $lat;

    /**
     * Longitude of the city center
     * @var double|null
     */
    protected $lng;

    /**
     * Hotel stars
     * @var int|null
     */
    protected $stars;

    /**
     * Hotel free places are present
     * @var bool|null
     */
    protected $fpn;

    /**
     * Hotel age
     * @var int|null
     */
    protected $age;

    /**
     * @return int
     */
    public function getPage(): int
    {
        return $this->page;
    }

    /**
     * @param int $page
     */
    public function setPage(int $page): void
    {
        $this->page = $page;
    }

    /**
     * @return int
     */
    public function getSize(): int
    {
        return $this->size;
    }

    /**
     * @param int $size
     */
    public function setSize(int $size): void
    {
        $this->size = $size;
    }

    /**
     * @return string|null
     */
    public function getN(): ?string
    {
        return $this->n;
    }

    /**
     * @param string|null $n
     */
    public function setN(?string $n): void
    {
        $this->n = $n;
    }

    /**
     * @return string|null
     */
    public function getC(): ?string
    {
        return $this->c;
    }

    /**
     * @param string|null $c
     */
    public function setC(?string $c): void
    {
        $this->c = $c;
    }

    /**
     * @return float|null
     */
    public function getLat(): ?float
    {
        return $this->lat;
    }

    /**
     * @param float|null $lat
     */
    public function setLat(?float $lat): void
    {
        $this->lat = $lat;
    }

    /**
     * @return float|null
     */
    public function getLng(): ?float
    {
        return $this->lng;
    }

    /**
     * @param float|null $lng
     */
    public function setLng(?float $lng): void
    {
        $this->lng = $lng;
    }

    /**
     * @return int|null
     */
    public function getStars(): ?int
    {
        return $this->stars;
    }

    /**
     * @param int|null $stars
     */
    public function setStars(?int $stars): void
    {
        $this->stars = $stars;
    }

    /**
     * @return bool|null
     */
    public function getFpn(): ?bool
    {
        return $this->fpn;
    }

    /**
     * @param bool|null $fpn
     */
    public function setFpn(?bool $fpn): void
    {
        $this->fpn = $fpn;
    }

    /**
     * @return int|null
     */
    public function getAge(): ?int
    {
        return $this->age;
    }

    /**
     * @param int|null $age
     */
    public function setAge(?int $age): void
    {
        $this->age = $age;
    }
}
