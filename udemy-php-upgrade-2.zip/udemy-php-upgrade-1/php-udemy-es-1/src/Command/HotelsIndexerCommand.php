<?php

namespace App\Command;

use App\Document\Booking;
use App\Document\Comment;
use App\Document\Hotel;
use App\Document\Hotels;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;
use ONGR\ElasticsearchBundle\Service\IndexService;

class HotelsIndexerCommand extends Command
{
    const COMMAND = 'udemy_phpes:hotels-indexer';
    const OPTION_OFFSET = 'offset';
    const OPTION_LIMIT = 'limit';
    const ARGUMENT_DEBUG = 'debug';

    private IndexService $hotelDocumentIndexService;
    private bool $debug = false;
    private OutputInterface $output;

    public function __construct(IndexService $hotelDocumentIndexService)
    {
        $this->hotelDocumentIndexService = $hotelDocumentIndexService;
        parent::__construct();
    }

    protected function configure()
    {
        $this
            ->setName(self::COMMAND)
            ->setDescription('Index hotel documents')
            ->addOption(
                self::OPTION_LIMIT,
                'l',
                InputOption::VALUE_REQUIRED,
                'Limit',
                3
            )
            ->addOption(
                self::OPTION_OFFSET,
                'o',
                InputOption::VALUE_REQUIRED,
                'Offset',
                0
            )
            ->addArgument(
                self::ARGUMENT_DEBUG,
                InputArgument::OPTIONAL,
                'Enable debug',
                false
            );
    }

    /**
     * @param InputInterface $input
     * @param OutputInterface $output
     */
    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->output = $output;
        $this->debug = $input->getArgument(self::ARGUMENT_DEBUG);
        $limit = $input->getOption(self::OPTION_LIMIT);
        $offset = $input->getOption(self::OPTION_OFFSET);
        $this->index($limit, $offset);

        return Command::SUCCESS;
    }

    /**
     * @param int $limit
     * @param int $offset
     */
    private function index(int $limit, int $offset)
    {
        $this->verboseWriteln('Perform indexing logic here.');
        $this->verboseWriteln(sprintf('Indexing %d hotels with offset %d...', $limit, $offset));
        $this->verboseWriteln(sprintf('Memory peak: %d MB', ceil(memory_get_peak_usage() / 1024 / 1024)));

        /*
         * Example of adding parent documents + nested objects
         */
        try {
            for ($i = 1; $i <= $limit; $i++) {
                $fileName = __DIR__.'/Data/'.$i.'.json';
                $data = json_decode(file_get_contents($fileName));

                $document = new Hotels();
                $hotel = new Hotel();

                $hotel->hotelId = $data->hotel->hotel_id;
                $hotel->email = $data->hotel->email;
                $hotel->cityNameEn = $data->hotel->city_name_en;
                $hotel->name = $data->hotel->name;
                $hotel->stars = $data->hotel->stars;
                $hotel->rating = $data->hotel->rating;
                $hotel->age = $data->hotel->age;
                $hotel->freePlacesAtNow = $data->hotel->free_places_at_now;
                $hotel->location = $data->hotel->location;

                foreach ($data->hotel->comments as $item) {
                    $comment = new Comment();
                    $comment->hotelId = $item->hotel_id;
                    $comment->content = $item->content;
                    $comment->stars = $item->stars;
                    $comment->createdAt = $item->created_at;
                    $hotel->addComment($comment);
                }

                $document->id = $data->hotel->hotel_id;
                $document->routing = 1;
                $document->hotel = $hotel;
                $document->hotelBookingsJoinField = ['name' => 'hotel_parent'];

                $this->hotelDocumentIndexService->persist($document);
                $this->hotelDocumentIndexService->commit();
            }
        } catch (\Throwable $t) {
            $this->verboseWriteln($t->getMessage());
        }

        /*
         * Example of adding child document
         */
        try {
            $booking = new Booking();
            $booking->date = "2021/08/01";
            $booking->price = 100;

            $document = new Hotels();
            $document->id = '1-4';
            $document->routing = 1;
            $document->booking = $booking;
            $document->hotelBookingsJoinField = [
                'name' => 'booking_child',
                'parent' => 1
            ];
            $this->hotelDocumentIndexService->persist($document);
            $this->hotelDocumentIndexService->commit();
        } catch (\Throwable $t) {
            $this->verboseWriteln($t->getMessage());
        }

        $this->verboseWriteln('END.');
    }

    private function verboseWriteln($str)
    {
        if ($this->debug) {
            $this->output->writeln($str);
        }
    }
}
