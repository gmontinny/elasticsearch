<?php

namespace App\Entity;

class HotelSearchCriteria
{
    const DEFAULT_PAGE = 1;
    const DEFAULT_SIZE = 10;
    const SIZE_MIN = 1;
    const SIZE_MAX = 20;

    /**
     * @var int
     */
    private $page = self::DEFAULT_PAGE;

    /**
     * @var int
     */
    private $size = self::DEFAULT_SIZE;

    /**
     * @ORM\Column(name="free_places_at_now", type="boolean", nullable=true)
     */
    private $freePlacesAtNow = false;

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     * @ORM\Column(name="hotel_name", type="string", length=500, nullable=false)
     */
    private $hotelName;

    /**
     * @var string
     * @ORM\Column(name="city_name", type="string", length=500, nullable=false)
     */
    private $cityName;

    /**
     * @var int
     *
     * @ORM\Column(name="hotel_age", type="integer", nullable=true)
     */
    private $hotelAge;

    /**
     * @var int
     *
     * @ORM\Column(name="hotel_stars", type="integer", nullable=true)
     */
    private $hotelStars;

    /**
     * @var array
     *
     * @ORM\Column(name="geo_coordinates", type="array", nullable=true, length=1000)
     */
    private $geoCoordinates = [];

    /**
     * @return int
     */
    public function getPage(): int
    {
        return $this->page;
    }

    /**
     * @param int $page
     */
    public function setPage(int $page): void
    {
        $this->page = $page;
    }

    /**
     * @return int
     */
    public function getSize(): int
    {
        return $this->size;
    }

    /**
     * @param int $size
     */
    public function setSize(int $size): void
    {
        $this->size = $size;
    }

    /**
     * @return mixed
     */
    public function getFreePlacesAtNow()
    {
        return $this->freePlacesAtNow;
    }

    /**
     * @param mixed $freePlacesAtNow
     */
    public function setFreePlacesAtNow($freePlacesAtNow): void
    {
        $this->freePlacesAtNow = $freePlacesAtNow;
    }

    /**
     * @return int
     */
    public function getId(): int
    {
        return $this->id;
    }

    /**
     * @param int $id
     */
    public function setId(int $id): void
    {
        $this->id = $id;
    }

    /**
     * @return string
     */
    public function getHotelName(): string
    {
        return $this->hotelName;
    }

    /**
     * @param string $hotelName
     */
    public function setHotelName(string $hotelName): void
    {
        $this->hotelName = $hotelName;
    }

    /**
     * @return string
     */
    public function getCityName(): string
    {
        return $this->cityName;
    }

    /**
     * @param string $cityName
     */
    public function setCityName(string $cityName): void
    {
        $this->cityName = $cityName;
    }

    /**
     * @return int
     */
    public function getHotelAge(): ?int
    {
        return $this->hotelAge;
    }

    /**
     * @param int $hotelAge
     */
    public function setHotelAge(int $hotelAge): void
    {
        $this->hotelAge = $hotelAge;
    }

    /**
     * @return int
     */
    public function getHotelStars(): int
    {
        return $this->hotelStars;
    }

    /**
     * @param int $hotelStars
     */
    public function setHotelStars(int $hotelStars): void
    {
        $this->hotelStars = $hotelStars;
    }

    /**
     * @return array
     */
    public function getGeoCoordinates(): array
    {
        return $this->geoCoordinates;
    }

    /**
     * @param array $geoCoordinates
     */
    public function setGeoCoordinates(array $geoCoordinates): void
    {
        $this->geoCoordinates = $geoCoordinates;
    }
}
