<?php

namespace App\Document;

use Doctrine\Common\Collections\ArrayCollection;
use ONGR\ElasticsearchBundle\Annotation as ES;

/**
 * @ES\ObjectType()
 */
class Hotel
{
    /**
     * @var int
     * @ES\Property(name="hotel_id", type="integer")
     */
    public $hotelId;

    /**
     * @var string
     * @ES\Property(name="email", type="text", analyzer="email")
     */
    public $email;

    /**
     * @var string
     * @ES\Property(
     *  type="text",
     *  name="name",
     *  fields={
     *     "keyword"={"type"="keyword"},
     *     "lowercased"={"type"="text", "analyzer"="lowercased_string"}
     *  }
     * )
     */
    public $name;

    /**
     * @var string
     * @ES\Property(name="city_name_en", type="text")
     */
    public $cityNameEn;

    /**
     * @var geo_point
     * @ES\Property(name="location", type="geo_point")
     */
    public $location;

    /**
     * @var int
     * @ES\Property(name="age", type="integer")
     */
    public $age;

    /**
     * @var int
     * @ES\Property(name="stars", type="integer")
     */
    public $stars;

    /**
     * @var float
     * @ES\Property(name="rating", type="float")
     */
    public $rating;

    /**
     * @var bool
     * @ES\Property(name="free_places_at_now", type="boolean")
     */
    public $freePlacesAtNow;

    /**
     * @var Comment
     * @ES\Embedded(class="App\Document\Comment")
     */
    public $comments;

    public function __construct()
    {
        $this->comments = new ArrayCollection();
    }

    public function addComment(Comment $comment)
    {
        $this->comments[] = $comment;

        return $this;
    }
}
