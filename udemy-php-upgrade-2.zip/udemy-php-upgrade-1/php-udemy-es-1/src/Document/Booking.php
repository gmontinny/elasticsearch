<?php

namespace App\Document;

use ONGR\ElasticsearchBundle\Annotation as ES;

/**
 * @ES\ObjectType()
 */
class Booking
{
    /**
     * @var float
     * @ES\Property(name="price", type="float")
     */
    public $price;

    /**
     * @var \DateTime
     * @ES\Property(
     *  type="date",
     *  name="date",
     *  settings={
     *     "format":"yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis"
     *  }
     * )
     */
    public $date;
}
