package com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search;

import com.udemy_sergii_java.spring_boot_es.model.criteria.HotelSearchCriteria;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;

public interface QueryBuilderInterface {
    void createQuery(HotelSearchCriteria criteria);

    NativeQuery getSearch();
}
