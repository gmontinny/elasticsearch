package com.udemy_sergii_java.spring_boot_es;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEsApplicationTests {

	@Test
	void contextLoads() {
	}

}
