## 1. Install java
    https://docs.aws.amazon.com/corretto/latest/corretto-11-ug/what-is-corretto-11.html
    
      Keep consistency between your local java version and Docker java version
      To avoid different distribution/version errors e.g: Exception in thread "main" java.lang.UnsupportedClassVersionError: 
      com/udemy_sergii_java/spring_boot_es/SpringBootEsApplication has been compiled by a more recent version 
      of the Java Runtime (class file version XX.0), this version of the Java Runtime only recognizes 
      class file versions up to YY.0

## 2. Install gradle
    https://gradle.org/install/

## 3a. Run clean java application with gradle
    ./gradlew build && java -jar build/libs/spring_boot_es-0.0.1-SNAPSHOT.jar

## 3b. Containerize java application with gradle
    ./gradlew build
    mkdir -p build/dependency && (cd build/dependency; for f in ../libs/*; do jar -xf $f; done)
    docker build -t springio/spring-boot-es-udemy .
    docker run -p 8080:8080 -t springio/spring-boot-es-udemy

    !!! use refresh.sh for fast and convenient work

## 3c. Build a Docker Image with Gradle
    ./gradlew bootBuildImage --imageName=springio/spring-boot-es-udemy

## 4. Bring up docker environment
      docker-compose up -d

## 5. Test url
      http://localhost:8080/test

## 6. Swagger UI
      http://localhost:8080/swagger-ui.html

## 7. Direct urls for testing
     http://localhost:8080/search?age=2&city=warsaw&fpn=true&hotel=star&lat=52.21&lng=21.01&page=1&size=10

# General documentation links

### Reference Documentation
For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.4.10/gradle-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.4.10/gradle-plugin/reference/html/#build-image)
* [Spring Web](https://docs.spring.io/spring-boot/docs/2.5.4/reference/htmlsingle/#boot-features-developing-web-applications)
* [Spring Data Elasticsearch (Access+Driver)](https://docs.spring.io/spring-boot/docs/2.5.4/reference/htmlsingle/#boot-features-elasticsearch)

### Guides
The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/bookmarks/)

### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)
