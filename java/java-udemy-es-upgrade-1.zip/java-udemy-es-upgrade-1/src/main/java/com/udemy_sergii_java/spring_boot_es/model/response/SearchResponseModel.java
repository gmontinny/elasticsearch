package com.udemy_sergii_java.spring_boot_es.model.response;

import java.io.Serializable;
import io.swagger.v3.oas.annotations.media.Schema;

@Schema
public class SearchResponseModel implements Serializable {
    @Schema(description = "Hotel name.",
            example = "Royal Beach", required = true)
    private String hotel;

    @Schema(description = "City name where hotel is located at English.",
            example = "London", required = true)
    private String city;

    @Schema(description = "Response status.",
            example = "200", required = false)
    private Integer status = 200;

    @Schema(description = "Error text.",
            example = "Exception", required = false)
    private String error = "";

    public SearchResponseModel(String hotel, String city) {
        this.hotel = hotel;
        this.city = city;
    }

    public String getHotel() {
        return hotel;
    }

    public void setHotel(String hotel) {
        this.hotel = hotel;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }
}
