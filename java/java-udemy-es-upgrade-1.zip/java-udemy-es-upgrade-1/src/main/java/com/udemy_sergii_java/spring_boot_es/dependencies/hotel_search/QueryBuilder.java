package com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search;

import com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search.filters.CityNameFilter;
import com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search.filters.GeoDistanceFilter;
import com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search.filters.HotelAgeFilter;
import com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search.filters.HotelNameFilter;
import com.udemy_sergii_java.spring_boot_es.model.criteria.HotelSearchCriteria;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;
import org.springframework.data.elasticsearch.client.elc.NativeQuery;
import org.springframework.data.elasticsearch.client.elc.NativeQueryBuilder;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryBuilders;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Component;


@Component
public class QueryBuilder implements QueryBuilderInterface {
    private NativeQueryBuilder searchQueryBuilder;
    private PageRequest pageRequest;

    public QueryBuilder() {
        this.searchQueryBuilder = new NativeQueryBuilder();
    }

    @Override
    public void createQuery(HotelSearchCriteria criteria) {
        this.setPageOffset(criteria);
        this.setFilters(criteria);
        this.setAggregation(criteria);
        this.setSorting(criteria);
        this.setFields(criteria);
    }

    @Override
    public NativeQuery getSearch() {
        return this.searchQueryBuilder.build();
    }

    public PageRequest getPageRequest() {
        return this.pageRequest;
    }

    protected void setFilters(HotelSearchCriteria criteria) {
        BoolQuery.Builder boolQueryBuilder = QueryBuilders.bool();

        if (!criteria.getHotelName().isEmpty()) {
            boolQueryBuilder.must(HotelNameFilter.createFilter(criteria));
        }

        if (!criteria.getCityName().isEmpty()) {
            boolQueryBuilder.must(CityNameFilter.createFilter(criteria));
        }

        if (criteria.getHotelAge() >= 0) {
            boolQueryBuilder.should(HotelAgeFilter.createFilter(criteria));
        }

        boolQueryBuilder.filter(GeoDistanceFilter.createFilter(criteria));

        this.searchQueryBuilder.withQuery(q -> q //
                .bool(boolQueryBuilder.build())
        );
    }

    protected void setPageOffset(HotelSearchCriteria criteria) {
        this.pageRequest = PageRequest.of(
                criteria.getPage(),
                criteria.getSize()
        );
        this.searchQueryBuilder.withPageable(this.pageRequest);
    }

    protected void setFields(HotelSearchCriteria criteria) {
        //choose fields you want to get from ElasticSearch
    }

    protected void setAggregation(HotelSearchCriteria criteria) {
        //add aggregations
    }

    protected void setSorting(HotelSearchCriteria criteria) {
        //add sorting
    }
}
