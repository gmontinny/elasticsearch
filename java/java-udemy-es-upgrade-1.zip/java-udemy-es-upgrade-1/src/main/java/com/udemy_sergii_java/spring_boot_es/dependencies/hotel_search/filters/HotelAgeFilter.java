package com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search.filters;

import com.udemy_sergii_java.spring_boot_es.model.criteria.HotelSearchCriteria;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryVariant;
import co.elastic.clients.elasticsearch._types.query_dsl.RangeQuery;
import co.elastic.clients.json.JsonData;

public class HotelAgeFilter {
    public static Query createFilter(HotelSearchCriteria criteria) {
        QueryVariant rangeAgeQuery = new RangeQuery.Builder()
                .field("age")
                .gte(JsonData.of(criteria.getHotelAge()))
                .build();

        return new Query(rangeAgeQuery);
    }
}
