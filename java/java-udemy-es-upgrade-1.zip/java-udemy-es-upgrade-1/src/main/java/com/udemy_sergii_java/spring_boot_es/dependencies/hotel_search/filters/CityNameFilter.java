package com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search.filters;

import com.udemy_sergii_java.spring_boot_es.model.criteria.HotelSearchCriteria;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryVariant;
import co.elastic.clients.elasticsearch._types.query_dsl.MatchQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryBuilders;
import co.elastic.clients.elasticsearch._types.query_dsl.BoolQuery;


public class CityNameFilter {
    public static Query createFilter(HotelSearchCriteria criteria) {
        QueryVariant matchQueryFirst = new MatchQuery.Builder()
                .field("cityNameEn")
                .query(criteria.getCityName())
                .fuzziness("2")
                .build();

        QueryVariant matchQuerySecond = new MatchQuery.Builder()
                .field("cityNameEn")
                .query("London")
                .build();

        BoolQuery.Builder boolQueryBuilder = QueryBuilders.bool();
        boolQueryBuilder.should(new Query(matchQueryFirst));
        boolQueryBuilder.should(new Query(matchQuerySecond));

        return new Query(boolQueryBuilder.build());
    }
}
