package com.udemy_sergii_java.spring_boot_es.dependencies.hotel_search.filters;

import com.udemy_sergii_java.spring_boot_es.model.criteria.HotelSearchCriteria;
import co.elastic.clients.elasticsearch._types.query_dsl.MatchQuery;
import co.elastic.clients.elasticsearch._types.query_dsl.Query;
import co.elastic.clients.elasticsearch._types.query_dsl.QueryVariant;


public class HotelNameFilter {
    public static Query createFilter(HotelSearchCriteria criteria) {

        QueryVariant matchHotelNameQuery = new MatchQuery.Builder()
                .field("name")
                .query(criteria.getHotelName())
                .build();

        return new Query(matchHotelNameQuery);
    }
}