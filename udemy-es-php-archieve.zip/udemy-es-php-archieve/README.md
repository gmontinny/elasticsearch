# Udemy Sergii Demianchuk PHP ElasticSearch Example

## Setup

1. Add hostname to your /etc/hosts file:

        127.0.0.1    udemy_phpes.com.test
        
2. Review the `.env` file and check the elastic connection URI.

3. Run docker compose to bring docker environment

        docker-compose up -d
        
4. Install dependencies

        docker exec -it udemy_phpes_php composer install

5. Drop Elasticsearch index (if exists)

        docker exec -it udemy_phpes_php bin/console ongr:es:index:drop -i hotels --force

6. Create Elasticsearch index

        docker exec -it udemy_phpes_php bin/console ongr:es:index:create -i hotels

7. Index hotels (that is only mock, logic should be added by yourself)

        docker exec -it udemy_phpes_php bin/console udemy_phpes:hotels-indexer debug

    With offset and limit:

        docker exec -it udemy_phpes_php bin/console udemy_phpes:hotels-indexer --offset 10000 --limit 1000
        
8. Run tests

    docker exec -it udemy_phpes_php bin/phpunit --testsuite unit
    
9. Check code style

    docker exec -it udemy_phpes_php vendor/bin/phpcs --standard=./ct3-ruleset.xml --extensions=php src/ --colors

## API point

1. Open swagger url:

        http://udemy_phpes.com.test/api/doc

2. Try to perform search using swagger or direct url e.g:

        http://udemy_phpes.com.test/api/search/hotels?page=1&size=10&n=star&c=warsaw&lat=52.21&lng=21.01&stars=4&fpn=true&age=5


