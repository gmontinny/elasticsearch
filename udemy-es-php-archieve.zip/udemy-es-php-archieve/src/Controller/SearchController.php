<?php

namespace App\Controller;

use App\DependencyInjection\HotelSearch\Search;
use App\DependencyInjection\HotelSearchCriteria\HotelSearchCriteriaUrlBuilder;
use App\DependencyInjection\HotelSearchCriteria\HotelSearchCriteriaDirector;
use App\Model\Response\SimpleSearchItemView;
use Exception;
use FOS\RestBundle\Controller\AbstractFOSRestController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Swagger\Annotations as SWG;
use Nelmio\ApiDocBundle\Annotation\Model;
use App\DependencyInjection\Swagger\Annotation\OperationWithParametersModel;
use App\Model\Request\SearchRequestView;
use App\Model\Response\SearchResponseView;

/**
 * @Route("/api/search", options={"expose": true})
 */
class SearchController extends AbstractFOSRestController
{
    /**
     * @Route("/hotels", name="get_hotels_search", methods={"GET"})
     * @OperationWithParametersModel(
     *     summary="Get list of hotels",
     *     tags={"search"},
     *     parametersModel=SearchRequestView::class,
     *     @SWG\Response(
     *        response=200,
     *        description="List of hotels",
     *        @Model(type=SearchResponseView::class)
     *     ),
     *     @SWG\Response(
     *         response="500",
     *         description="Error"
     *     )
     * )
     *
     * @param Search $search
     * @param Request $request
     * @return Response
     * @throws Exception
     */
    public function getHotelsSearchAction(Search $search, Request $request): Response
    {
        $requestQueryData = $request->query->all();
//        dump($requestQueryData);
        $builder = new HotelSearchCriteriaUrlBuilder($requestQueryData);

        $director = new HotelSearchCriteriaDirector($builder);
        $director->buildCriteria();

//        dump($director->getCriteria());die;

        $results = $search->searchRaw($director->getCriteria());

//        dump($results);die;

        $itemsViewsArray = [];
        foreach ($results as $item) {
            $itemsViewsArray[] = SimpleSearchItemView::createFromHotel($item);
        }

        $resultsView = new SearchResponseView();
        $resultsView->setResults($itemsViewsArray);
        $view = $this->view($resultsView);
//        throw new Exception('debug via profiler: http://udemy_phpes.com.test/_profiler');

        return $this->handleView($view);
    }
}
