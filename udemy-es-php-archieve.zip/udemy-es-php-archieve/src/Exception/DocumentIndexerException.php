<?php

namespace App\Exception;

class DocumentIndexerException extends \Exception
{
    const DEFAULT_SEPARATOR = '. ';

    const DOCUMENT_ELASTIC_ERROR_CODE = 100;
    const DOCUMENT_ELASTIC_ERROR_MESSAGE = 'Elastic encountered an error while trying to index entity: %d';

    const DOCUMENT_GENERATOR_ERROR_CODE = 102;
    const DOCUMENT_GENERATOR_ERROR_MESSAGE = 'Error generating data in %s';

    /**
     * @param string $entityClass
     * @param int $entityId
     * @param \Exception $previousException
     * @return DocumentIndexerException
     */
    public static function createWithElasticError($entityId, \Exception $previousException, $entityClass)
    {
        $customMessage = $entityClass . ' ' . sprintf(self::DOCUMENT_ELASTIC_ERROR_MESSAGE, $entityId);
        $message = self::concatMessages($customMessage, $previousException->getMessage());

        return new self($message, self::DOCUMENT_ELASTIC_ERROR_CODE, $previousException);
    }

    /**
     * @param string $generatorName
     * @param \Exception $previousException
     * @return DocumentIndexerException
     */
    public static function createWithDataGeneratorError($generatorName, \Exception $previousException)
    {
        $customMessage = sprintf(self::DOCUMENT_GENERATOR_ERROR_MESSAGE, $generatorName);
        $message = self::concatMessages($customMessage, $previousException->getMessage());

        return new self($message, self::DOCUMENT_GENERATOR_ERROR_CODE, $previousException);
    }

    /**
     * @param $messageFirst
     * @param $messageSecond
     * @return string
     */
    public static function concatMessages($messageFirst, $messageSecond)
    {
        return $messageFirst . self::DEFAULT_SEPARATOR . $messageSecond;
    }
}
