<?php

namespace App\DependencyInjection\HotelSearchCriteria;

use App\Entity\HotelSearchCriteria;

class HotelSearchCriteriaDirector extends AbstractCriteriaDirector
{
    /**
     * @var AbstractCriteriaBuilder|null
     */
    private $builder = null;

    /**
     * @param AbstractCriteriaBuilder $builder
     */
    public function __construct(AbstractCriteriaBuilder $builder)
    {
        $this->builder = $builder;
    }

    public function buildCriteria(): void
    {
        $this->builder->createCriteria();
    }

    public function getCriteria(): HotelSearchCriteria
    {
        return $this->builder->getCriteria();
    }
}
