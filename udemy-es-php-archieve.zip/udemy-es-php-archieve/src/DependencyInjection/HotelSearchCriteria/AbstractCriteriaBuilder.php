<?php

namespace App\DependencyInjection\HotelSearchCriteria;

abstract class AbstractCriteriaBuilder
{
    abstract public function getCriteria();

    abstract public function createCriteria();
}
