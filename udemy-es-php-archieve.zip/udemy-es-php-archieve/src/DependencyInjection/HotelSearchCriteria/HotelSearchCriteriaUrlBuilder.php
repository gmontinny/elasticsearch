<?php

namespace App\DependencyInjection\HotelSearchCriteria;

use App\Entity\HotelSearchCriteria;

class HotelSearchCriteriaUrlBuilder extends AbstractCriteriaBuilder
{
    const PAGE = 'page';
    const SIZE = 'size';

    const HOTEL_NAME = "n";
    const HOTEL_CITY_NAME_EN = "c";
    const CITY_CENTER_LAT = "lat";
    const CITY_CENTER_LNG = "lng";
    const HOTEL_STARTS = "stars";
    const HOTEL_FREE_PLACES = "fpn";
    const HOTEL_AGE = "age";

    /**
     * @var HotelSearchCriteria
     */
    private $criteria;

    /**
     * @var array
     */
    private $data;

    /**
     * @param null|array $data
     */
    public function __construct(?array $data)
    {
        $this->criteria = new HotelSearchCriteria();
        $this->data = $data;
    }

    /**
     * @return void
     */
    public function createCriteria()
    {
        $data = $this->data;
        if (isset($data[self::PAGE]) && is_numeric($data[self::PAGE])) {
            $this->criteria->setPage((int) $data[self::PAGE]);
        }
        if (isset($data[self::SIZE])
            && ($data[self::SIZE] >= HotelSearchCriteria::SIZE_MIN)
            && ($data[self::SIZE] <= HotelSearchCriteria::SIZE_MAX)
        ) {
            $this->criteria->setSize((int) $data[self::SIZE]);
        }

        if (isset($data[self::HOTEL_AGE])) {
            $this->criteria->setHotelAge((int) $data[self::HOTEL_AGE]);
        }

        if (isset($data[self::HOTEL_STARTS])) {
            $this->criteria->setHotelStars((int) $data[self::HOTEL_STARTS]);
        }

        if (isset($data[self::HOTEL_CITY_NAME_EN]) && is_string($data[self::HOTEL_CITY_NAME_EN])) {
            $this->criteria->setCityName((string) $data[self::HOTEL_CITY_NAME_EN]);
        }

        if (isset($data[self::HOTEL_NAME]) && is_string($data[self::HOTEL_NAME])) {
            $this->criteria->setHotelName((string) $data[self::HOTEL_NAME]);
        }

        if (isset($data[self::HOTEL_FREE_PLACES]) && is_bool($data[self::HOTEL_FREE_PLACES])) {
            $this->criteria->setFreePlacesAtNow((bool) $data[self::HOTEL_FREE_PLACES]);
        }

        if (isset($data[self::CITY_CENTER_LAT])
            && is_numeric($data[self::CITY_CENTER_LAT])
            && isset($data[self::CITY_CENTER_LNG])
            && is_numeric($data[self::CITY_CENTER_LNG])) {
            $this->criteria->setGeoCoordinates([
                'lat' => $data[self::CITY_CENTER_LAT],
                'lon' => $data[self::CITY_CENTER_LNG]
            ]);
        }
    }

    /**
     * @return HotelSearchCriteria
     */
    public function getCriteria(): HotelSearchCriteria
    {
        return $this->criteria;
    }
}
