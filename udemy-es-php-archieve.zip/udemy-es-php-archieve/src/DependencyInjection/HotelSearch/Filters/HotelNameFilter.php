<?php

namespace App\DependencyInjection\HotelSearch\Filters;

use App\Entity\HotelSearchCriteria;
use ONGR\ElasticsearchDSL\BuilderInterface;
use ONGR\ElasticsearchDSL\Query\Compound\BoolQuery;
use ONGR\ElasticsearchDSL\Query\FullText\MatchQuery;

class HotelNameFilter extends AbstractFilter
{
    public static function createFilter(HotelSearchCriteria $criteria): BuilderInterface
    {
        $boolQuery = new BoolQuery();
        $matchQuery = new MatchQuery('hotel.name', $criteria->getHotelName(), []);
        $boolQuery->add($matchQuery, BoolQuery::MUST);

        return $boolQuery;
    }
}
