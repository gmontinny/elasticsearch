<?php

namespace App\DependencyInjection\HotelSearch\Filters;

use App\Entity\HotelSearchCriteria;
use ONGR\ElasticsearchDSL\BuilderInterface;
use ONGR\ElasticsearchDSL\Query\Compound\BoolQuery;
use ONGR\ElasticsearchDSL\Query\Geo\GeoDistanceQuery;
use ONGR\ElasticsearchDSL\Query\MatchAllQuery;

class GeoDistanceFilter extends AbstractFilter
{
    public static function createFilter(HotelSearchCriteria $criteria): BuilderInterface
    {
        $boolQuery = new BoolQuery();
        $boolQuery->add(new MatchAllQuery());
        $geoQuery = new GeoDistanceQuery(
            'hotel.location',
            '30km',
            $criteria->getGeoCoordinates()
        );
        $boolQuery->add($geoQuery, BoolQuery::FILTER);

        return $boolQuery;
    }
}
