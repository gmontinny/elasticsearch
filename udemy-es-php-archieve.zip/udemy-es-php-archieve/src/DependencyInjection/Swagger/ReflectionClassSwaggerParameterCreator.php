<?php

namespace App\DependencyInjection\Swagger;

use Swagger\Annotations as SWG;
use Doctrine\Common\Annotations\AnnotationReader;
use Symfony\Component\PropertyInfo\Extractor\PhpDocExtractor;
use Symfony\Component\PropertyInfo\Extractor\ReflectionExtractor;
use Symfony\Component\PropertyInfo\PropertyInfoExtractor;

/**
 * Class ReflectionClassSwaggerParameterCreator
 *
 * Analyzes a DTD model class using reflection in order to create the Swagger Parameter objects.
 *
 * @package ApiBundle\DependencyInjection\Swagger
 */
class ReflectionClassSwaggerParameterCreator
{
    /**
     * Maps from internal PHP type to Swagger type
     */
    const TYPES_MAP = [
        'string' => 'string',
        'int' => 'integer',
        'double' => 'number',
        'float' => 'number',
        'integer' => 'number',
        'bool' => 'boolean',
        'boolean' => 'boolean',
        'array' => 'array',
        'object' => 'object',
    ];

    /**
     * @var AnnotationReader
     */
    private $annotationReader;

    /**
     * @var PropertyInfoExtractor
     */
    private $propertyInfoExtractor;


    public function __construct()
    {
        $this->annotationReader = new AnnotationReader();
        $this->propertyInfoExtractor = $this->createPropertyInfoExtractor();
    }

    /**
     * @param string $modelClassName
     * @return array
     * @throws \ReflectionException
     */
    public function createParameters(string $modelClassName): array
    {
        if (!class_exists($modelClassName)) {
            throw new \LogicException("Class $modelClassName does not exists.");
        }

        $parameters = [];
        $reflectionClass = new \ReflectionClass($modelClassName);
        $reflectionProperties = $reflectionClass->getProperties();

        foreach ($reflectionProperties as $reflectionProperty) {
            $parameters[] = $this->createParameter($reflectionProperty);
        }

        return $parameters;
    }

    /**
     * @param \ReflectionProperty $reflectionProperty
     * @return SWG\Parameter
     */
    private function createParameter(\ReflectionProperty $reflectionProperty): SWG\Parameter
    {
        $className = $reflectionProperty->getDeclaringClass()->getName();
        $propertyName = $reflectionProperty->getName();

        /** @var SWG\Parameter $parameter */
        $parameter = $this->annotationReader->getPropertyAnnotation($reflectionProperty, SWG\Parameter::class);
        if (empty($parameter)) {
            $parameter = new SWG\Parameter([
                'name' => $reflectionProperty->getName(),
                'in' => 'query'
            ]);
        } else {
            $parameter->name = $reflectionProperty->getName();
            if (empty($parameter->in)) {
                $parameter->in = 'query';
            }
        }

        $parameter->description = $this->propertyInfoExtractor->getShortDescription($className, $propertyName);

        $this->setParameterType($parameter, $className, $propertyName);

        return $parameter;
    }

    /**
     * @param SWG\Parameter $parameter
     * @param string $className
     * @param string $propertyName
     */
    private function setParameterType(SWG\Parameter $parameter, string $className, string $propertyName)
    {
        $type = 'string';

        $varTypesArray = $this->propertyInfoExtractor->getTypes($className, $propertyName);
        if (!empty($varTypesArray) and is_array($varTypesArray)) {
            // get only first type
            $varTypeObj = reset($varTypesArray);

            /* @var $varTypeObj \Symfony\Component\PropertyInfo\Type */
            $builtinType = $varTypeObj->getBuiltinType();
            if (isset(self::TYPES_MAP[$builtinType])) {
                $type = self::TYPES_MAP[$builtinType];
            } elseif (class_exists($builtinType)) {
                $type = $builtinType;
            } else {
                $type = $builtinType;
            }
        }

        $parameter->type = $type;
    }

    /**
     * @return PropertyInfoExtractor
     */
    private function createPropertyInfoExtractor(): PropertyInfoExtractor
    {
        $phpDocExtractor = new PhpDocExtractor();
        $reflectionExtractor = new ReflectionExtractor();

        // array of PropertyListExtractorInterface
        $listExtractors = [$reflectionExtractor];

        // array of PropertyTypeExtractorInterface
        $typeExtractors = [$phpDocExtractor, $reflectionExtractor];

        // array of PropertyDescriptionExtractorInterface
        $descriptionExtractors = [$phpDocExtractor];

        // array of PropertyAccessExtractorInterface
        $accessExtractors = [$reflectionExtractor];

        return new PropertyInfoExtractor(
            $listExtractors,
            $typeExtractors,
            $descriptionExtractors,
            $accessExtractors
        );
    }
}
