<?php

namespace App\Document;

use ONGR\ElasticsearchBundle\Annotation as ES;

/**
 * @ES\Index()
 */
class Hotels
{
    /**
     * @var int
     * @ES\Id()
     */
    public $id;

    /**
     * @var int
     * @ES\Routing()
     */
    public $routing;

    /**
     * @var Hotel
     * @ES\Embedded(class="App\Document\Hotel")
     */
    public $hotel;

    /**
     * @var Booking
     * @ES\Embedded(class="App\Document\Booking")
     */
    public $booking;

    /**
     * @var string
     * @ES\Property(
     *  type="join",
     *  name="hotel_bookings_join_field",
     *  settings={
     *     "relations"={"hotel_parent": "booking_child"}
     *  }
     * )
     */
    public $hotelBookingsJoinField;

    public function __construct()
    {
        $this->hotel = [];
        $this->booking = [];
    }
}
