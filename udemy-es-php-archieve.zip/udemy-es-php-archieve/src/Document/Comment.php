<?php

namespace App\Document;

use ONGR\ElasticsearchBundle\Annotation as ES;

/**
 * @ES\NestedType()
 */
class Comment
{
    /**
     * @var int
     * @ES\Property(name="hotel_id", type="integer")
     */
    public $hotelId;

    /**
     * @var string
     * @ES\Property(name="content", type="text")
     */
    public $content;

    /**
     * @var int
     * @ES\Property(name="stars", type="integer")
     */
    public $stars;

    /**
     * @var \DateTime
     * @ES\Property(
     *  type="date",
     *  name="created_at",
     *  settings={
     *     "format":"yyyy/MM/dd HH:mm:ss||yyyy/MM/dd||epoch_millis"
     *  }
     * )
     */
    public $createdAt;
}
