<?php

namespace App\Model\Response;

class SimpleSearchItemView
{
    /**
     * Hotel name
     * @var string|null
     */
    protected $name;

    /**
     * Hotel stars
     * @var int|null
     */
    protected $stars;

    /**
     * @return string|null
     */
    public function getName(): ?string
    {
        return $this->name;
    }

    /**
     * @param string|null $name
     */
    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    /**
     * @return int|null
     */
    public function getStars(): ?int
    {
        return $this->stars;
    }

    /**
     * @param int|null $stars
     */
    public function setStars(?int $stars): void
    {
        $this->stars = $stars;
    }

    public static function createFromHotel(array $document)
    {
        $view = new static;
        $hotel = $document['_source']['hotel'];

        $view->name = $hotel['name'];
        $view->stars = $hotel['stars'];

        return $view;
    }
}
